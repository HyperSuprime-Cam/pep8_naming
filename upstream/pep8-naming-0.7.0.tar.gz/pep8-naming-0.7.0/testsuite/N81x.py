#: Okay
import good as good
#: Okay
from mod import good as nice, NICE as GOOD, Camel as Memel
#: N811
from mod import GOOD as bad
#: N812
from mod import good as Bad
#: N813
from mod import CamelCase as noncamle
#: N814
from mod import CamelCase as CONSTANT
