#: N801
class notok(object):
    pass
#: N801
class Good(object):
    class notok(object):
        pass
    pass
#: Okay
class VeryGood(object):
    pass
