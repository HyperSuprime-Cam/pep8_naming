# python2 only
#: Okay
def test(a, b, (good, verygood)):
    pass
#: N803
def bad(a, b, (OHH, NOO)):
    pass
