#: Okay
GLOBAL_UPPER_CASE = 0
#: N816
mixedCase = 0
#: N816:1:1
mixed_Case = 0
#: Okay
_C = 0
#: Okay
__D = 0
#: N816
__mC = 0
#: N816
__mC__ = 0
#: Okay
__C6__ = 0
#: Okay
C6 = 0
#: Okay
C_6 = 0.
#: Okay(--ignore-names=mixedCase)
mixedCase = 0
