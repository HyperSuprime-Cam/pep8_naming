# python_version >= '3'
#: Okay
class Γ:
    pass
#: Okay
class ΓγΓγ:
    pass
#: Okay
class ΓγΓ6:
    pass
#: Okay
class _Γ:
    pass
#: N801:1:7
class γ:
    pass
#: N801
class _γ:
    pass
