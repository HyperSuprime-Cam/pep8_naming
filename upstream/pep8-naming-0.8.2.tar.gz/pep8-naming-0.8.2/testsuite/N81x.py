#: N812:1:1
import os as OS
#: Okay
import os as myos
#: Okay
import good as good
#: Okay
import underscore as _
#: Okay
from mod import good as nice, NICE as GOOD, Camel as Memel
#: N811:1:1
from mod import GOOD as bad
#: N812:1:1
from mod import good as Bad
#: N813:1:1
from mod import CamelCase as noncamle
#: N814:1:1
from mod import CamelCase as CONSTANT
