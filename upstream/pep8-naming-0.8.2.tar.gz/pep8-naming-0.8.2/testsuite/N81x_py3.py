# python_version >= '3'
#: Okay
import good as γ
#: Okay
from mod import good as γ
#: Okay
import GOOD as Γ
#: Okay
from mod import GOOD as Γ
#: Okay
from mod import GOOD as Γ1
