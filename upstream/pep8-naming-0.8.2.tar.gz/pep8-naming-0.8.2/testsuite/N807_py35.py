# python_version >= '3.5'
#: Okay
class C:
    async def γ(self):
        pass
#: N807
async def __β(self):
    pass
