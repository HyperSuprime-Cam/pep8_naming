# python_version >= '3'
#: Okay
class C:
    def γ(self):
        pass
#: N807
def __β(self):
    pass
#: N807
def __β6(self):
    pass
#: Okay
class C:
    def γ1(self):
        pass
